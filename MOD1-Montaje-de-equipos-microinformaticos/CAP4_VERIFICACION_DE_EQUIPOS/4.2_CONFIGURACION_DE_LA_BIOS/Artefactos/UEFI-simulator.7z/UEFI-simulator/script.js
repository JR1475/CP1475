// Estado del sistema UEFI
const uefiState = {
    // Main
    systemInfo: {
        motherboard: "ASUS ROG STRIX Z690-E",
        cpu: "Intel Core i9-13900K",
        memory: "32 GB DDR5",
        firmwareVersion: "3803",
        dateTime: "2024-06-15 10:30:00"
    },

    // Boot
    boot: {
        secureBoot: true,
        csmEnabled: false,
        bootOrder: [
            "Windows Boot Manager (UEFI)",
            "Ubuntu (UEFI)",
            "UEFI: Samsung SSD 980 PRO",
            "USB: Kingston DataTraveler"
        ],
        legacyOrder: ["Hard Drive", "CD/DVD", "USB"]
    },

    // Security
    security: {
        supervisorPasswordSet: false,
        userPasswordSet: false,
        tpmEnabled: true,
        secureBootMode: "Standard" // or "Custom"
    },

    // Advanced
    overclocking: {
        xmpProfile: "DDR5-6000",
        cpuRatio: 54,
        vcore: 1.35,
        loadLineCalibration: "Level 5"
    },

    // Monitor
    health: {
        cpuTemp: 62,
        mbTemp: 45,
        cpuFanRpm: 1800,
        vcoreVolts: 1.34
    },
    
    // Estado de la aplicación
    currentMode: "ez-mode", // "ez-mode" o "advanced"
    unsavedChanges: false
};

// Elementos del DOM
const tabs = document.querySelectorAll('.tab');
const content = document.getElementById('uefi-content');
const systemTime = document.getElementById('system-time');
const notificationContainer = document.getElementById('notification-container');

// Gráficos
let tempChart = null;
let fanChart = null;

// Inicialización
function init() {
    // Configurar eventos de pestañas
    tabs.forEach(tab => {
        tab.addEventListener('click', () => {
            const tabName = tab.getAttribute('data-tab');
            switchTab(tabName);
        });
    });

    // Cargar la primera pestaña
    switchTab('ez-mode');

    // Actualizar hora del sistema
    updateSystemTime();
    setInterval(updateSystemTime, 1000);

    // Configurar atajos de teclado
    setupKeyboardShortcuts();
}

// Cambiar entre pestañas
function switchTab(tabName) {
    // Actualizar pestañas activas
    tabs.forEach(tab => {
        if (tab.getAttribute('data-tab') === tabName) {
            tab.classList.add('active');
        } else {
            tab.classList.remove('active');
        }
    });

    // Cargar contenido según la pestaña
    switch(tabName) {
        case 'ez-mode':
            loadEZMode();
            break;
        case 'advanced':
            loadAdvancedMode();
            break;
        case 'boot':
            loadBootTab();
            break;
        case 'security':
            loadSecurityTab();
            break;
        case 'monitor':
            loadMonitorTab();
            break;
        case 'exit':
            loadExitTab();
            break;
    }
}

// Cargar contenido del Modo Fácil (EZ Mode)
function loadEZMode() {
    uefiState.currentMode = "ez-mode";
    
    content.innerHTML = `
        <div class="ez-mode-container fade-in">
            <div class="ez-mode-header">
                <h2>Modo Fácil (EZ Mode)</h2>
                <button class="button" id="advanced-mode-btn">
                    <i class="fas fa-cogs"></i>
                    Modo Avanzado
                </button>
            </div>
            
            <div class="ez-mode-grid">
                <div class="ez-mode-card">
                    <h3>Información del Sistema</h3>
                    <div>
                        <div class="info-item">
                            <span class="info-label">CPU:</span>
                            <span class="info-value">${uefiState.systemInfo.cpu}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Memoria:</span>
                            <span class="info-value">${uefiState.systemInfo.memory}</span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Placa Base:</span>
                            <span class="info-value">${uefiState.systemInfo.motherboard}</span>
                        </div>
                    </div>
                </div>
                
                <div class="ez-mode-card">
                    <h3>Estado del Sistema</h3>
                    <div>
                        <div class="status-item">
                            <span class="status-label">Temperatura CPU:</span>
                            <span class="status-value">
                                ${uefiState.health.cpuTemp}°C
                                <span class="temp-indicator ${getTempStatus(uefiState.health.cpuTemp)}"></span>
                            </span>
                        </div>
                        <div class="status-item">
                            <span class="status-label">Ventilador CPU:</span>
                            <span class="status-value">${uefiState.health.cpuFanRpm} RPM</span>
                        </div>
                        <div class="status-item">
                            <span class="status-label">Voltaje:</span>
                            <span class="status-value">${uefiState.health.vcoreVolts}V</span>
                        </div>
                    </div>
                </div>
                
                <div class="ez-mode-card">
                    <h3>Arranque</h3>
                    <div>
                        <div class="boot-item">
                            <span class="boot-label">Dispositivo de Arranque:</span>
                            <div class="dropdown" id="ez-boot-dropdown">
                                <div class="dropdown-trigger">
                                    <span>${uefiState.boot.bootOrder[0]}</span>
                                    <span>▼</span>
                                </div>
                                <div class="dropdown-menu">
                                    ${uefiState.boot.bootOrder.map(device => `
                                        <div class="dropdown-item" data-value="${device}">${device}</div>
                                    `).join('')}
                                </div>
                            </div>
                        </div>
                        <div class="boot-item">
                            <span class="boot-label">Secure Boot:</span>
                            <div class="setting-value">
                                <div class="toggle-switch ${uefiState.boot.secureBoot ? 'active' : ''}" id="ez-secure-boot-toggle">
                                    <div class="toggle-slider"></div>
                                </div>
                                <span>${uefiState.boot.secureBoot ? 'Activado' : 'Desactivado'}</span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="ez-mode-card">
                    <h3>Acciones Rápidas</h3>
                    <div class="quick-actions">
                        <button class="button primary" id="ez-save-exit-btn">
                            <i class="fas fa-save"></i>
                            Guardar y Reiniciar
                        </button>
                        <button class="button success" id="ez-xmp-btn">
                            <i class="fas fa-memory"></i>
                            Activar XMP
                        </button>
                        <button class="button" id="ez-fan-tuning-btn">
                            <i class="fas fa-fan"></i>
                            Ajustar Ventiladores
                        </button>
                    </div>
                </div>
            </div>
            
            <div class="ez-mode-footer">
                <p>Presione F7 para cambiar al Modo Avanzado o haga clic en el botón "Modo Avanzado".</p>
            </div>
        </div>
    `;
    
    // Configurar eventos para el modo fácil
    document.getElementById('advanced-mode-btn').addEventListener('click', function() {
        switchTab('advanced');
    });
    
    document.getElementById('ez-secure-boot-toggle').addEventListener('click', function() {
        uefiState.boot.secureBoot = !uefiState.boot.secureBoot;
        this.classList.toggle('active');
        this.nextElementSibling.textContent = uefiState.boot.secureBoot ? 'Activado' : 'Desactivado';
        markUnsavedChanges();
        
        if (!uefiState.boot.secureBoot) {
            showNotification('Secure Boot desactivado. El sistema puede ser vulnerable.', 'warning');
        }
    });
    
    setupDropdown('ez-boot-dropdown', (value) => {
        // Mover el dispositivo seleccionado al principio de la lista de arranque
        const index = uefiState.boot.bootOrder.indexOf(value);
        if (index > 0) {
            uefiState.boot.bootOrder.splice(index, 1);
            uefiState.boot.bootOrder.unshift(value);
            markUnsavedChanges();
            showNotification(`Dispositivo de arranque cambiado a: ${value}`, 'success');
        }
    });
    
    document.getElementById('ez-save-exit-btn').addEventListener('click', function() {
        saveAndRestart();
    });
    
    document.getElementById('ez-xmp-btn').addEventListener('click', function() {
        uefiState.overclocking.xmpProfile = "DDR5-6000";
        markUnsavedChanges();
        showNotification('Perfil XMP DDR5-6000 activado. El sistema se reiniciará para aplicar los cambios.', 'success');
    });
    
    document.getElementById('ez-fan-tuning-btn').addEventListener('click', function() {
        showNotification('Abriendo utilidad de ajuste de ventiladores...', 'info');
        // En una implementación real, abriríamos una ventana modal con opciones de ajuste de ventiladores
    });
}

// Cargar contenido del Modo Avanzado
function loadAdvancedMode() {
    uefiState.currentMode = "advanced";
    
    content.innerHTML = `
        <div class="setting-group fade-in">
            <div class="setting-header">
                <span>Información del Sistema</span>
                <button class="button" id="ez-mode-btn">
                    <i class="fas fa-home"></i>
                    Modo Fácil
                </button>
            </div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Placa Base</div>
                    <div class="setting-value">${uefiState.systemInfo.motherboard}</div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Procesador</div>
                    <div class="setting-value">${uefiState.systemInfo.cpu}</div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Memoria</div>
                    <div class="setting-value">${uefiState.systemInfo.memory}</div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Versión del Firmware</div>
                    <div class="setting-value">${uefiState.systemInfo.firmwareVersion}</div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Fecha y Hora</div>
                    <div class="setting-value" id="datetime-setting">${uefiState.systemInfo.dateTime}</div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Configuración de CPU</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Ratio de CPU</div>
                    <div class="setting-value">
                        <div class="slider-container">
                            <input type="range" min="12" max="60" value="${uefiState.overclocking.cpuRatio}" id="cpu-ratio-slider" class="slider">
                            <span class="slider-value" id="cpu-ratio-value">${uefiState.overclocking.cpuRatio}</span>
                        </div>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Voltaje (VCore)</div>
                    <div class="setting-value">
                        <div class="slider-container">
                            <input type="range" min="1.0" max="1.5" step="0.01" value="${uefiState.overclocking.vcore}" id="vcore-slider" class="slider">
                            <span class="slider-value" id="vcore-value">${uefiState.overclocking.vcore}V</span>
                        </div>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Load-Line Calibration</div>
                    <div class="setting-value">
                        <div class="dropdown" id="llc-dropdown">
                            <div class="dropdown-trigger">
                                <span>${uefiState.overclocking.loadLineCalibration}</span>
                                <span>▼</span>
                            </div>
                            <div class="dropdown-menu">
                                <div class="dropdown-item" data-value="Level 1">Level 1</div>
                                <div class="dropdown-item" data-value="Level 2">Level 2</div>
                                <div class="dropdown-item" data-value="Level 3">Level 3</div>
                                <div class="dropdown-item" data-value="Level 4">Level 4</div>
                                <div class="dropdown-item" data-value="Level 5">Level 5</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Configuración de Memoria</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Perfil XMP</div>
                    <div class="setting-value">
                        <div class="dropdown" id="xmp-dropdown">
                            <div class="dropdown-trigger">
                                <span>${uefiState.overclocking.xmpProfile}</span>
                                <span>▼</span>
                            </div>
                            <div class="dropdown-menu">
                                <div class="dropdown-item" data-value="Disabled">Disabled</div>
                                <div class="dropdown-item" data-value="DDR5-4800">DDR5-4800</div>
                                <div class="dropdown-item" data-value="DDR5-5400">DDR5-5400</div>
                                <div class="dropdown-item" data-value="DDR5-6000">DDR5-6000</div>
                                <div class="dropdown-item" data-value="DDR5-6400">DDR5-6400</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Advertencia de Overclocking</div>
            <div class="setting-content">
                <p>El overclocking puede causar inestabilidad del sistema y potencialmente dañar componentes. Proceda con caution y bajo su propio riesgo.</p>
                <div style="margin-top: 15px;">
                    <button class="button danger" id="reset-oc-btn">
                        <i class="fas fa-undo"></i>
                        Restablecer Configuración
                    </button>
                </div>
            </div>
        </div>
    `;
    
    // Configurar evento para volver al modo fácil
    document.getElementById('ez-mode-btn').addEventListener('click', function() {
        switchTab('ez-mode');
    });
    
    // Configurar eventos para los sliders
    const cpuRatioSlider = document.getElementById('cpu-ratio-slider');
    const cpuRatioValue = document.getElementById('cpu-ratio-value');
    
    cpuRatioSlider.addEventListener('input', function() {
        uefiState.overclocking.cpuRatio = parseInt(this.value);
        cpuRatioValue.textContent = this.value;
        markUnsavedChanges();
    });

    const vcoreSlider = document.getElementById('vcore-slider');
    const vcoreValue = document.getElementById('vcore-value');
    
    vcoreSlider.addEventListener('input', function() {
        uefiState.overclocking.vcore = parseFloat(this.value);
        vcoreValue.textContent = this.value + 'V';
        markUnsavedChanges();
    });

    // Configurar eventos para los dropdowns
    setupDropdown('llc-dropdown', (value) => {
        uefiState.overclocking.loadLineCalibration = value;
        markUnsavedChanges();
    });

    setupDropdown('xmp-dropdown', (value) => {
        uefiState.overclocking.xmpProfile = value;
        markUnsavedChanges();
        
        if (value !== 'Disabled') {
            showNotification(`Perfil XMP ${value} aplicado. El sistema se reiniciará para aplicar los cambios.`, 'success');
        }
    });

    // Configurar evento para el botón de restablecimiento
    document.getElementById('reset-oc-btn').addEventListener('click', function() {
        if (confirm('¿Está seguro de que desea restablecer toda la configuración de overclocking?')) {
            uefiState.overclocking = {
                xmpProfile: "DDR5-6000",
                cpuRatio: 54,
                vcore: 1.35,
                loadLineCalibration: "Level 5"
            };
            
            // Recargar la pestaña para reflejar los cambios
            loadAdvancedMode();
            showNotification('Configuración de overclocking restablecida a los valores predeterminados.', 'success');
        }
    });
    
    // Actualizar fecha y hora en tiempo real
    setInterval(() => {
        const datetimeElement = document.getElementById('datetime-setting');
        if (datetimeElement) {
            datetimeElement.textContent = uefiState.systemInfo.dateTime;
        }
    }, 1000);
}

// Cargar contenido de la pestaña Arranque
function loadBootTab() {
    content.innerHTML = `
        <div class="setting-group fade-in">
            <div class="setting-header">Configuración de Arranque</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Secure Boot</div>
                    <div class="setting-value">
                        <div class="toggle-switch ${uefiState.boot.secureBoot ? 'active' : ''}" id="secure-boot-toggle">
                            <div class="toggle-slider"></div>
                        </div>
                        <span>${uefiState.boot.secureBoot ? 'Activado' : 'Desactivado'}</span>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">CSM (Compatibility Support Module)</div>
                    <div class="setting-value">
                        <div class="toggle-switch ${uefiState.boot.csmEnabled ? 'active' : ''}" id="csm-toggle">
                            <div class="toggle-slider"></div>
                        </div>
                        <span>${uefiState.boot.csmEnabled ? 'Activado' : 'Desactivado'}</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Prioridad de Arranque UEFI</div>
            <div class="setting-content">
                <div id="boot-order-list">
                    ${uefiState.boot.bootOrder.map((device, index) => `
                        <div class="setting-item boot-order-item" data-index="${index}" draggable="true">
                            <div class="setting-label">
                                <i class="fas fa-grip-vertical"></i>
                                ${index + 1}. ${device}
                            </div>
                            <div class="setting-value">
                                <button class="button move-up" data-index="${index}" ${index === 0 ? 'disabled' : ''}>
                                    <i class="fas fa-arrow-up"></i>
                                </button>
                                <button class="button move-down" data-index="${index}" ${index === uefiState.boot.bootOrder.length - 1 ? 'disabled' : ''}>
                                    <i class="fas fa-arrow-down"></i>
                                </button>
                            </div>
                        </div>
                    `).join('')}
                </div>
            </div>
        </div>
    `;

    // Configurar eventos para los toggles
    document.getElementById('secure-boot-toggle').addEventListener('click', function() {
        uefiState.boot.secureBoot = !uefiState.boot.secureBoot;
        this.classList.toggle('active');
        this.nextElementSibling.textContent = uefiState.boot.secureBoot ? 'Activado' : 'Desactivado';
        markUnsavedChanges();
        
        if (!uefiState.boot.secureBoot) {
            showNotification('Secure Boot desactivado. El sistema puede ser vulnerable.', 'warning');
        }
    });

    document.getElementById('csm-toggle').addEventListener('click', function() {
        uefiState.boot.csmEnabled = !uefiState.boot.csmEnabled;
        this.classList.toggle('active');
        this.nextElementSibling.textContent = uefiState.boot.csmEnabled ? 'Activado' : 'Desactivado';
        markUnsavedChanges();
        
        if (uefiState.boot.csmEnabled && uefiState.boot.secureBoot) {
            showNotification('CSM activado. Secure Boot será desactivado para compatibilidad.', 'warning');
            uefiState.boot.secureBoot = false;
            document.getElementById('secure-boot-toggle').classList.remove('active');
            document.getElementById('secure-boot-toggle').nextElementSibling.textContent = 'Desactivado';
        }
    });

    // Configurar eventos para reordenar la lista de arranque
    document.querySelectorAll('.move-up').forEach(button => {
        button.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            if (index > 0) {
                // Intercambiar elementos
                [uefiState.boot.bootOrder[index], uefiState.boot.bootOrder[index - 1]] = 
                [uefiState.boot.bootOrder[index - 1], uefiState.boot.bootOrder[index]];
                
                // Recargar la pestaña para reflejar los cambios
                loadBootTab();
                markUnsavedChanges();
            }
        });
    });

    document.querySelectorAll('.move-down').forEach(button => {
        button.addEventListener('click', function() {
            const index = parseInt(this.getAttribute('data-index'));
            if (index < uefiState.boot.bootOrder.length - 1) {
                // Intercambiar elementos
                [uefiState.boot.bootOrder[index], uefiState.boot.bootOrder[index + 1]] = 
                [uefiState.boot.bootOrder[index + 1], uefiState.boot.bootOrder[index]];
                
                // Recargar la pestaña para reflejar los cambios
                loadBootTab();
                markUnsavedChanges();
            }
        });
    });
    
    // Configurar drag and drop para la lista de arranque
    setupDragAndDrop();
}

// Cargar contenido de la pestaña Seguridad
function loadSecurityTab() {
    content.innerHTML = `
        <div class="setting-group fade-in">
            <div class="setting-header">Contraseñas</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Contraseña de Supervisor</div>
                    <div class="setting-value">
                        <button class="button" id="supervisor-password-btn">
                            <i class="fas fa-key"></i>
                            ${uefiState.security.supervisorPasswordSet ? 'Cambiar' : 'Establecer'}
                        </button>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Contraseña de Usuario</div>
                    <div class="setting-value">
                        <button class="button" id="user-password-btn">
                            <i class="fas fa-key"></i>
                            ${uefiState.security.userPasswordSet ? 'Cambiar' : 'Establecer'}
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Seguridad del Sistema</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">TPM (Trusted Platform Module)</div>
                    <div class="setting-value">
                        <div class="toggle-switch ${uefiState.security.tpmEnabled ? 'active' : ''}" id="tpm-toggle">
                            <div class="toggle-slider"></div>
                        </div>
                        <span>${uefiState.security.tpmEnabled ? 'Activado' : 'Desactivado'}</span>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Modo Secure Boot</div>
                    <div class="setting-value">
                        <div class="dropdown" id="secure-boot-mode-dropdown">
                            <div class="dropdown-trigger">
                                <span>${uefiState.security.secureBootMode}</span>
                                <span>▼</span>
                            </div>
                            <div class="dropdown-menu">
                                <div class="dropdown-item" data-value="Standard">Standard</div>
                                <div class="dropdown-item" data-value="Custom">Custom</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `;

    // Configurar eventos para los toggles
    document.getElementById('tpm-toggle').addEventListener('click', function() {
        uefiState.security.tpmEnabled = !uefiState.security.tpmEnabled;
        this.classList.toggle('active');
        this.nextElementSibling.textContent = uefiState.security.tpmEnabled ? 'Activado' : 'Desactivado';
        markUnsavedChanges();
    });

    // Configurar eventos para el dropdown
    setupDropdown('secure-boot-mode-dropdown', (value) => {
        uefiState.security.secureBootMode = value;
        markUnsavedChanges();
    });

    // Configurar eventos para los botones de contraseña
    document.getElementById('supervisor-password-btn').addEventListener('click', function() {
        const password = prompt('Introduzca la contraseña de supervisor:');
        if (password) {
            uefiState.security.supervisorPasswordSet = true;
            this.innerHTML = '<i class="fas fa-key"></i> Cambiar';
            markUnsavedChanges();
            showNotification('Contraseña de supervisor establecida correctamente.', 'success');
        }
    });

    document.getElementById('user-password-btn').addEventListener('click', function() {
        const password = prompt('Introduzca la contraseña de usuario:');
        if (password) {
            uefiState.security.userPasswordSet = true;
            this.innerHTML = '<i class="fas fa-key"></i> Cambiar';
            markUnsavedChanges();
            showNotification('Contraseña de usuario establecida correctamente.', 'success');
        }
    });
}

// Cargar contenido de la pestaña Monitor
function loadMonitorTab() {
    content.innerHTML = `
        <div class="setting-group fade-in">
            <div class="setting-header">Estado del Sistema</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Temperatura CPU</div>
                    <div class="setting-value">
                        <span id="cpu-temp-value">${uefiState.health.cpuTemp}°C</span>
                        <span class="temp-indicator ${getTempStatus(uefiState.health.cpuTemp)}"></span>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Temperatura Placa Base</div>
                    <div class="setting-value">
                        <span id="mb-temp-value">${uefiState.health.mbTemp}°C</span>
                        <span class="temp-indicator ${getTempStatus(uefiState.health.mbTemp)}"></span>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Velocidad Ventilador CPU</div>
                    <div class="setting-value">
                        <span id="cpu-fan-value">${uefiState.health.cpuFanRpm} RPM</span>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Voltaje VCore</div>
                    <div class="setting-value">
                        <span id="vcore-volts-value">${uefiState.health.vcoreVolts}V</span>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Gráficos en Tiempo Real</div>
            <div class="setting-content">
                <div class="chart-container">
                    <canvas id="temp-chart"></canvas>
                </div>
                <div class="chart-container">
                    <canvas id="fan-chart"></canvas>
                </div>
            </div>
        </div>
    `;

    // Inicializar gráficos
    initMonitorCharts();
    
    // Actualizar valores en tiempo real
    setInterval(updateMonitorValues, 2000);
}

// Cargar contenido de la pestaña Salir
function loadExitTab() {
    content.innerHTML = `
        <div class="setting-group fade-in">
            <div class="setting-header">Opciones de Salida</div>
            <div class="setting-content">
                <div class="setting-item">
                    <div class="setting-label">Guardar Cambios y Reiniciar</div>
                    <div class="setting-value">
                        <button class="button primary" id="save-exit-btn">
                            <i class="fas fa-save"></i>
                            Guardar y Reiniciar
                        </button>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Descartar Cambios y Reiniciar</div>
                    <div class="setting-value">
                        <button class="button" id="discard-exit-btn">
                            <i class="fas fa-times-circle"></i>
                            Descartar y Reiniciar
                        </button>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Cargar Perfil Optimizado</div>
                    <div class="setting-value">
                        <button class="button success" id="load-optimized-btn">
                            <i class="fas fa-magic"></i>
                            Cargar Optimizado
                        </button>
                    </div>
                </div>
                <div class="setting-item">
                    <div class="setting-label">Guardar Perfil</div>
                    <div class="setting-value">
                        <button class="button" id="save-profile-btn">
                            <i class="fas fa-save"></i>
                            Guardar Perfil
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="setting-group fade-in">
            <div class="setting-header">Información de Cambios</div>
            <div class="setting-content">
                <div id="changes-list">
                    ${uefiState.unsavedChanges ? 
                        '<p style="color: var(--accent-orange);"><i class="fas fa-exclamation-triangle"></i> Tiene cambios sin guardar.</p>' : 
                        '<p>No hay cambios pendientes.</p>'}
                </div>
            </div>
        </div>
    `;

    // Configurar eventos para los botones
    document.getElementById('save-exit-btn').addEventListener('click', function() {
        saveAndRestart();
    });

    document.getElementById('discard-exit-btn').addEventListener('click', function() {
        if (confirm('¿Está seguro de que desea descartar todos los cambios y reiniciar el sistema?')) {
            showNotification('Descartando cambios y reiniciando...', 'warning');
            
            // Simular reinicio
            setTimeout(() => {
                showRestartScreen();
            }, 1500);
        }
    });

    document.getElementById('load-optimized-btn').addEventListener('click', function() {
        if (confirm('¿Está seguro de que desea cargar la configuración optimizada? Se perderán todos los cambios actuales.')) {
            // Restablecer a valores predeterminados
            uefiState.boot.secureBoot = true;
            uefiState.boot.csmEnabled = false;
            uefiState.security.tpmEnabled = true;
            uefiState.security.secureBootMode = "Standard";
            uefiState.overclocking = {
                xmpProfile: "DDR5-6000",
                cpuRatio: 54,
                vcore: 1.35,
                loadLineCalibration: "Level 5"
            };
            
            uefiState.unsavedChanges = false;
            
            showNotification('Configuración optimizada cargada correctamente.', 'success');
            
            // Recargar la pestaña para reflejar los cambios
            loadExitTab();
        }
    });

    document.getElementById('save-profile-btn').addEventListener('click', function() {
        const profileName = prompt('Introduzca un nombre para el perfil:');
        if (profileName) {
            // En una implementación real, guardaríamos el perfil en localStorage o en una base de datos
            localStorage.setItem(`uefi-profile-${profileName}`, JSON.stringify(uefiState));
            showNotification(`Perfil "${profileName}" guardado correctamente.`, 'success');
        }
    });
}

// Funciones auxiliares
function updateSystemTime() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    
    const formattedDateTime = `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
    uefiState.systemInfo.dateTime = formattedDateTime;
    systemTime.textContent = formattedDateTime;
}

function setupKeyboardShortcuts() {
    document.addEventListener('keydown', function(e) {
        // F1: Ayuda
        if (e.key === 'F1') {
            e.preventDefault();
            showNotification('Ayuda: Use las pestañas para navegar por las diferentes configuraciones. F10 para guardar y salir, ESC para salir sin guardar.', 'info');
        }
        
        // F10: Guardar y Salir
        if (e.key === 'F10') {
            e.preventDefault();
            saveAndRestart();
        }
        
        // ESC: Salir sin Guardar
        if (e.key === 'Escape') {
            e.preventDefault();
            if (confirm('¿Está seguro de que desea salir sin guardar los cambios?')) {
                showNotification('Saliendo sin guardar...', 'warning');
                
                // Simular reinicio
                setTimeout(() => {
                    showRestartScreen();
                }, 1500);
            }
        }
        
        // F7: Cambiar entre EZ Mode y Advanced Mode
        if (e.key === 'F7') {
            e.preventDefault();
            if (uefiState.currentMode === 'ez-mode') {
                switchTab('advanced');
            } else {
                switchTab('ez-mode');
            }
        }
    });
}

function setupDropdown(dropdownId, callback) {
    const dropdown = document.getElementById(dropdownId);
    if (!dropdown) return;
    
    const dropdownTrigger = dropdown.querySelector('.dropdown-trigger');
    const dropdownItems = dropdown.querySelectorAll('.dropdown-item');

    dropdownTrigger.addEventListener('click', function() {
        // Cerrar otros dropdowns abiertos
        document.querySelectorAll('.dropdown.open').forEach(openDropdown => {
            if (openDropdown !== dropdown) {
                openDropdown.classList.remove('open');
            }
        });
        
        dropdown.classList.toggle('open');
    });

    dropdownItems.forEach(item => {
        item.addEventListener('click', function() {
            const value = this.getAttribute('data-value');
            dropdown.querySelector('.dropdown-trigger span').textContent = value;
            dropdown.classList.remove('open');
            
            if (callback) {
                callback(value);
            }
        });
    });

    // Cerrar dropdown al hacer clic fuera
    document.addEventListener('click', function(e) {
        if (!dropdown.contains(e.target)) {
            dropdown.classList.remove('open');
        }
    });
}

function getTempStatus(temp) {
    if (temp < 60) return 'temp-normal';
    if (temp < 80) return 'temp-warning';
    return 'temp-critical';
}

function showNotification(message, type = 'info', title = null) {
    // Crear elemento de notificación
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    
    if (title) {
        notification.innerHTML = `
            <div class="notification-title">${title}</div>
            <div>${message}</div>
        `;
    } else {
        notification.textContent = message;
    }
    
    // Añadir al contenedor de notificaciones
    notificationContainer.appendChild(notification);
    
    // Mostrar con animación
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    // Ocultar después de 3 segundos
    setTimeout(() => {
        notification.classList.remove('show');
        
        // Eliminar del DOM después de la animación
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

function markUnsavedChanges() {
    uefiState.unsavedChanges = true;
    
    // Actualizar indicador de cambios sin guardar si estamos en la pestaña de salida
    const changesList = document.getElementById('changes-list');
    if (changesList) {
        changesList.innerHTML = '<p style="color: var(--accent-orange);"><i class="fas fa-exclamation-triangle"></i> Tiene cambios sin guardar.</p>';
    }
}

function saveAndRestart() {
    if (confirm('¿Está seguro de que desea guardar los cambios y reiniciar el sistema?')) {
        uefiState.unsavedChanges = false;
        showNotification('Guardando cambios y reiniciando...', 'success');
        
        // Simular reinicio
        setTimeout(() => {
            showRestartScreen();
        }, 1500);
    }
}

function showRestartScreen() {
    document.body.innerHTML = `
        <div class="restart-screen">
            <h2>Reiniciando sistema...</h2>
            <div class="loading-dots">
                <span></span>
                <span></span>
                <span></span>
            </div>
            <p style="margin-top: 30px; color: var(--text-secondary);">No apague el equipo</p>
        </div>
    `;
    
    // Simular finalización del reinicio y volver a la aplicación
    setTimeout(() => {
        location.reload();
    }, 5000);
}

function initMonitorCharts() {
    const tempCanvas = document.getElementById('temp-chart');
    const fanCanvas = document.getElementById('fan-chart');
    
    if (tempCanvas && fanCanvas) {
        // Configuración del gráfico de temperatura
        const tempCtx = tempCanvas.getContext('2d');
        tempChart = new Chart(tempCtx, {
            type: 'line',
            data: {
                labels: Array(10).fill('').map((_, i) => `${i * 2}s`),
                datasets: [{
                    label: 'Temperatura CPU',
                    data: Array(10).fill(0).map(() => 60 + Math.random() * 10),
                    borderColor: '#ff6b00',
                    backgroundColor: 'rgba(255, 107, 0, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Temperatura Placa Base',
                    data: Array(10).fill(0).map(() => 40 + Math.random() * 10),
                    borderColor: '#0078d7',
                    backgroundColor: 'rgba(0, 120, 215, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 20,
                        max: 100,
                        ticks: {
                            color: '#a0a0a0'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#a0a0a0'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: '#e0e0e0'
                        }
                    }
                }
            }
        });
        
        // Configuración del gráfico de ventilador
        const fanCtx = fanCanvas.getContext('2d');
        fanChart = new Chart(fanCtx, {
            type: 'line',
            data: {
                labels: Array(10).fill('').map((_, i) => `${i * 2}s`),
                datasets: [{
                    label: 'Velocidad Ventilador CPU',
                    data: Array(10).fill(0).map(() => 1500 + Math.random() * 500),
                    borderColor: '#00cc6a',
                    backgroundColor: 'rgba(0, 204, 106, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        min: 800,
                        max: 2500,
                        ticks: {
                            color: '#a0a0a0'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#a0a0a0'
                        },
                        grid: {
                            color: 'rgba(255, 255, 255, 0.1)'
                        }
                    }
                },
                plugins: {
                    legend: {
                        labels: {
                            color: '#e0e0e0'
                        }
                    }
                }
            }
        });
    }
}

function updateMonitorValues() {
    // Simular cambios en los valores del monitor
    const cpuTempElement = document.getElementById('cpu-temp-value');
    const mbTempElement = document.getElementById('mb-temp-value');
    const cpuFanElement = document.getElementById('cpu-fan-value');
    const vcoreVoltsElement = document.getElementById('vcore-volts-value');
    
    if (cpuTempElement) {
        // Simular fluctuación de temperatura
        const variation = (Math.random() - 0.5) * 4;
        uefiState.health.cpuTemp = Math.round(uefiState.health.cpuTemp + variation);
        cpuTempElement.textContent = `${uefiState.health.cpuTemp}°C`;
        
        // Actualizar indicador de temperatura
        const indicator = cpuTempElement.nextElementSibling;
        indicator.className = `temp-indicator ${getTempStatus(uefiState.health.cpuTemp)}`;
    }
    
    if (mbTempElement) {
        // Simular fluctuación de temperatura
        const variation = (Math.random() - 0.5) * 2;
        uefiState.health.mbTemp = Math.round(uefiState.health.mbTemp + variation);
        mbTempElement.textContent = `${uefiState.health.mbTemp}°C`;
        
        // Actualizar indicador de temperatura
        const indicator = mbTempElement.nextElementSibling;
        indicator.className = `temp-indicator ${getTempStatus(uefiState.health.mbTemp)}`;
    }
    
    if (cpuFanElement) {
        // Simular fluctuación de RPM
        const variation = Math.round((Math.random() - 0.5) * 200);
        uefiState.health.cpuFanRpm = Math.max(800, uefiState.health.cpuFanRpm + variation);
        cpuFanElement.textContent = `${uefiState.health.cpuFanRpm} RPM`;
    }
    
    if (vcoreVoltsElement) {
        // Simular fluctuación de voltaje
        const variation = (Math.random() - 0.5) * 0.02;
        uefiState.health.vcoreVolts = Math.round((uefiState.health.vcoreVolts + variation) * 100) / 100;
        vcoreVoltsElement.textContent = `${uefiState.health.vcoreVolts}V`;
    }
    
    // Actualizar gráficos si existen
    if (tempChart && fanChart) {
        // Actualizar gráfico de temperatura
        tempChart.data.labels.shift();
        tempChart.data.labels.push(`${tempChart.data.labels.length * 2}s`);
        
        tempChart.data.datasets[0].data.shift();
        tempChart.data.datasets[0].data.push(uefiState.health.cpuTemp);
        
        tempChart.data.datasets[1].data.shift();
        tempChart.data.datasets[1].data.push(uefiState.health.mbTemp);
        
        tempChart.update('none');
        
        // Actualizar gráfico de ventilador
        fanChart.data.labels.shift();
        fanChart.data.labels.push(`${fanChart.data.labels.length * 2}s`);
        
        fanChart.data.datasets[0].data.shift();
        fanChart.data.datasets[0].data.push(uefiState.health.cpuFanRpm);
        
        fanChart.update('none');
    }
}

function setupDragAndDrop() {
    const bootOrderItems = document.querySelectorAll('.boot-order-item');
    let draggedItem = null;
    
    bootOrderItems.forEach(item => {
        item.addEventListener('dragstart', function(e) {
            draggedItem = this;
            this.classList.add('dragging');
            e.dataTransfer.effectAllowed = 'move';
            e.dataTransfer.setData('text/html', this.innerHTML);
        });
        
        item.addEventListener('dragend', function() {
            this.classList.remove('dragging');
        });
        
        item.addEventListener('dragover', function(e) {
            if (e.preventDefault) {
                e.preventDefault();
            }
            e.dataTransfer.dropEffect = 'move';
            
            // Añadir indicador visual
            this.classList.add('drag-over');
            return false;
        });
        
        item.addEventListener('dragleave', function() {
            this.classList.remove('drag-over');
        });
        
        item.addEventListener('drop', function(e) {
            if (e.stopPropagation) {
                e.stopPropagation();
            }
            
            this.classList.remove('drag-over');
            
            if (draggedItem !== this) {
                // Intercambiar elementos en el array
                const draggedIndex = parseInt(draggedItem.getAttribute('data-index'));
                const targetIndex = parseInt(this.getAttribute('data-index'));
                
                [uefiState.boot.bootOrder[draggedIndex], uefiState.boot.bootOrder[targetIndex]] = 
                [uefiState.boot.bootOrder[targetIndex], uefiState.boot.bootOrder[draggedIndex]];
                
                // Recargar la pestaña para reflejar los cambios
                loadBootTab();
                markUnsavedChanges();
            }
            
            return false;
        });
    });
}

// Inicializar la aplicación
init();
